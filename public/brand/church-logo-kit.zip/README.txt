CHRIST IN ME GOSPEL ARENA - Brand Assets
Correct spelling: CHRIST IN ME (not CHRIS IN ME).
Use the scalable SVG for print and large compositions.
Included 320px PNG previews and vector SVG variants.
For high-resolution transparent PNGs and 1024 x 1024 square PNGs see the source repository's public/brand folder.
https://github.com/Kingsley-A1/chris-in-me/tree/main/public/brand
